
<?php

include "includes/db.php";

 //if (isset($_GET['uid'] && $_GET['fid'])) {
$user_id = $_GET['uid'];
$friend_id = $_GET['fid'];




//$sql = "UPDATE `todo` SET `finished`=1 WHERE id=".$task_id;

//mysqli_close($con);

//echo json_encode(array('success' => 1, 'task' => $task_id));


/*Get Loged user name */
$query1 = "SELECT * FROM users WHERE id=" . $user_id;
$res1 = mysqli_query($con, $query1);
 while ($row1 = mysqli_fetch_assoc($res1)) {
	 $loged_name = $row1['name'];
	 $loged_image = $row1['image'];
	
 }


 /*Get target friend name */
$query2 = "SELECT * FROM users WHERE id=" . $friend_id;
$res2 = mysqli_query($con, $query2);
 while ($row2 = mysqli_fetch_assoc($res2)) {
	 $friend_name = $row2['name'];
	 $friend_image = $row2['user_image'];
	
 }
 
 
//echo $user_id . " , " . $friend_id . " , " . $friend_name . ", image: " . $friend_image . ", " . $loged_name . ", " . $loged_image;



$query = "SELECT body, sender_id FROM messages WHERE sender_id = '$user_id' or sender_id= '$friend_id' AND reciver_id = '$user_id' or reciver_id = '$friend_id' ORDER BY sent_date ASC";
$res = mysqli_query($con, $query);
 while ($row = mysqli_fetch_assoc($res)) {
	 // if you need message for one we need another select from that table to get the message for one user i
	 $message = $row['body'];
	 $sender = $row['sender_id'];

 

	}
	
	if ($friend_name == $sender) {
		echo $message . "Friend sender : " . $friend_image;
	} 
   	
	if ($user_id == $sender) {
		echo $message . "User sender : " . $loged_image;
	}	
	





?>